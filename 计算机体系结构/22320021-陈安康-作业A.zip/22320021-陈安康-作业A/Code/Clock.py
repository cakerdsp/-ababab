clock = 0
